<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ExtraProductInfo extends Model
{
   	protected $table = 'product_extra_info';
}