<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TradeIn extends Model
{
   	protected $table = 'trade_ins';
}