<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LeadComment extends Model
{
   	protected $table = 'lead_comments';
}